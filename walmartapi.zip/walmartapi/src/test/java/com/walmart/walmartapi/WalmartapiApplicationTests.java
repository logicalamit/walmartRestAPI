package com.walmart.walmartapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WalmartapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
